import imageCompression from 'browser-image-compression';

const MAX_FILE_SIZE_KB = 20; // 20 KB

/**
 * Compresses a file to under 20KB
 * For images: uses browser-image-compression
 * For other files: tries to reduce size through other means or returns original if compression isn't possible
 */
export async function compressFile(file: File): Promise<File> {
  const fileSizeKB = file.size / 1024;
  
  // If already under 20KB, return as-is
  if (fileSizeKB <= MAX_FILE_SIZE_KB) {
    return file;
  }

  const fileType = file.type;
  const fileName = file.name.toLowerCase();

  // Handle image files
  if (fileType.startsWith('image/') || 
      fileName.match(/\.(jpg|jpeg|png|gif|webp|bmp)$/i)) {
    try {
      // Calculate quality and max dimensions to get under 20KB
      let quality = 0.8;
      let maxWidthOrHeight = 1920;
      
      // Try compression with decreasing quality/dimensions until we get under 20KB
      let compressedFile: File = file;
      let attempts = 0;
      const maxAttempts = 5;

      while (compressedFile.size / 1024 > MAX_FILE_SIZE_KB && attempts < maxAttempts) {
        const options = {
          maxSizeMB: MAX_FILE_SIZE_KB / 1024, // Convert KB to MB
          maxWidthOrHeight,
          useWebWorker: true,
          fileType: fileType || undefined,
          initialQuality: quality,
        };

        compressedFile = await imageCompression(file, options);
        
        // Adjust for next attempt if still too large
        if (compressedFile.size / 1024 > MAX_FILE_SIZE_KB) {
          quality = Math.max(0.3, quality - 0.1);
          maxWidthOrHeight = Math.max(400, maxWidthOrHeight - 200);
        }
        
        attempts++;
      }

      // If still too large after compression attempts, return the best we could do
      if (compressedFile.size / 1024 > MAX_FILE_SIZE_KB) {
        console.warn(`File ${file.name} could not be compressed to under ${MAX_FILE_SIZE_KB}KB. Final size: ${(compressedFile.size / 1024).toFixed(2)}KB`);
        // Try one more aggressive compression
        const finalOptions = {
          maxSizeMB: MAX_FILE_SIZE_KB / 1024,
          maxWidthOrHeight: 800,
          useWebWorker: true,
          initialQuality: 0.5,
        };
        compressedFile = await imageCompression(file, finalOptions);
      }

      return compressedFile;
    } catch (error) {
      console.error('Image compression failed:', error);
      // Return original file if compression fails
      return file;
    }
  }

  // Handle PDF files - try to compress by converting to lower quality
  // Note: PDF compression is limited in browser, may need server-side processing
  if (fileType === 'application/pdf' || fileName.endsWith('.pdf')) {
    // For PDFs, we can't really compress in browser without server-side tools
    // Return as-is for now (or implement client-side PDF compression if needed)
    console.warn('PDF compression not supported in browser. File size:', (file.size / 1024).toFixed(2), 'KB');
    return file;
  }

  // For other file types, return as-is
  // Could implement additional compression strategies here
  console.warn(`File type ${fileType} compression not implemented. File size: ${(file.size / 1024).toFixed(2)}KB`);
  return file;
}

/**
 * Gets file type category for determining which viewer to use
 */
export function getFileTypeCategory(fileName: string, mimeType?: string): 'pdf' | 'image' | 'document' | 'other' {
  const lowerName = fileName.toLowerCase();
  const lowerMime = (mimeType || '').toLowerCase();

  if (lowerName.endsWith('.pdf') || lowerMime.includes('pdf')) {
    return 'pdf';
  }

  if (lowerName.match(/\.(jpg|jpeg|png|gif|webp|bmp|svg)$/i) || 
      lowerMime.startsWith('image/')) {
    return 'image';
  }

  if (lowerName.match(/\.(doc|docx|xls|xlsx|txt|rtf)$/i) ||
      lowerMime.includes('document') || lowerMime.includes('spreadsheet')) {
    return 'document';
  }

  return 'other';
}

